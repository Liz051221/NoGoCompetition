"""Competition engine entry points."""
